#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
APP="$DIR/MT Studio.app"
BIN="$APP/Contents/MacOS/mtstudio"
chmod +x "$BIN" "$DIR/Open MT Studio.command" 2>/dev/null
xattr -dr com.apple.quarantine "$DIR" 2>/dev/null
# Prefer opening the site directly — the .app is a convenience.
open "https://memetorrent.futuret3ch.com.au/studio"
