#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
APP="$DIR/MT Studio.app"
xattr -dr com.apple.quarantine "$APP" "$DIR" 2>/dev/null || true
open "$APP"
